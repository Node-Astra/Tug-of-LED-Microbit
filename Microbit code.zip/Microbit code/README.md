Please do not actually claim this as you're own

if you reupload as in changing the code of it please add credit to me.

In other words fuck this code up and mess with it. It is for everyone to use!


